Hey! Thanks for picking up WulfsGames Auto-Reedemer app.

Please follow the next steps to use the redeemer:

1. Install node for your operating system: https://nodejs.org/en/download/
2. In this folder, open config.json with any text editor and fill up your Steam Login Credentials
(the "owner" refers to our steam account, from which we will send messages with steam keys, If you want us
to fill your steam profile with games instead of you doing it, you can change it to any ID64 you want to otherwise)
3. You can either fill up your games.txt file with the key codes you want to be activated. Their format can be:

a) XXXXX-XXXXX-XXXXX
b) Game Name | XXXXX-XXXXX-XXXXX (It is important for the sepparator to be "|")

4. Run start.bat and enjoy.